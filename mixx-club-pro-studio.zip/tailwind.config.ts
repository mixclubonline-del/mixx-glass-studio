
import type { Config } from "tailwindcss";

export default {
  content: ["./app/**/*.{ts,tsx}", "./src/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Mixx Club palette
        prime: {
          50:  "#f6f5ff",
          100: "#efeaff",
          200: "#dcd2ff",
          300: "#c3adff",
          400: "#a17aff",
          500: "#7d46ff",
          600: "#5d26e6",
          700: "#4719b3",
          800: "#351186",
          900: "#240a5c"
        },
        neon: {
          blue: "#00c2ff",
          pink: "#ff4fd8",
          purple: "#9b5cff"
        },
        glass: "rgba(255,255,255,0.06)"
      },
      boxShadow: {
        glow: "0 0 30px rgba(155,92,255,0.35), 0 0 60px rgba(0,194,255,0.25)"
      },
      backdropBlur: {
        xs: "2px"
      }
    },
  },
  plugins: [],
} satisfies Config;
