
'use client';

import ProStudio from "@/src/studio/ProStudio";

export default function Page() {
  return <ProStudio />;
}
