
'use client';
import React, { useEffect, useRef } from 'react';

type Props = { duration: number; playhead: number; onSeek: (sec:number)=>void; };

export default function Timeline({ duration, playhead, onSeek }: Props){
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(()=>{
    const cvs = canvasRef.current!;
    const ctx = cvs.getContext('2d')!;
    const draw = ()=>{
      const w = cvs.width, h = cvs.height;
      ctx.clearRect(0,0,w,h);
      ctx.fillStyle = "rgba(255,255,255,0.06)";
      ctx.fillRect(0,0,w,h);
      // grid
      ctx.strokeStyle = "rgba(255,255,255,0.1)";
      ctx.lineWidth = 1;
      const seconds = Math.ceil(duration);
      for (let s=0; s<=seconds; s++){
        const x = (s/seconds)*w;
        ctx.beginPath();
        ctx.moveTo(x, 0); ctx.lineTo(x, h);
        ctx.stroke();
        ctx.fillStyle = "rgba(255,255,255,0.6)";
        ctx.fillText(String(s), x+4, 12);
      }
      // playhead
      const x = (playhead / duration) * w;
      ctx.strokeStyle = "#9b5cff";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x, 0); ctx.lineTo(x, h);
      ctx.stroke();
    };
    draw();
  }, [duration, playhead]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-16 rounded-md border border-white/10 cursor-pointer"
      width={1200}
      height={64}
      onClick={(e)=>{
        const rect = (e.target as HTMLCanvasElement).getBoundingClientRect();
        const x = e.clientX - rect.left;
        const pct = x / rect.width;
        onSeek(pct * duration);
      }}
    />
  );
}
