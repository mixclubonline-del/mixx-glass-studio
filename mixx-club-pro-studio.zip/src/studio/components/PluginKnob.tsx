
'use client';
import React from 'react';

type Props = {
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (v:number)=>void;
  label?: string;
};

export default function PluginKnob({ value, min=0, max=1, step=0.01, onChange, label }: Props){
  const pct = (value - min) / (max - min);
  const angle = -140 + 280 * pct;

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative w-16 h-16 rounded-full border border-white/15 glass"
        onWheel={(e)=>{
          e.preventDefault();
          const delta = (e.deltaY<0 ? step : -step);
          const nv = Math.min(max, Math.max(min, value + delta));
          onChange(parseFloat(nv.toFixed(4)));
        }}
        onMouseDown={(e)=>{
          const startY = e.clientY; const start = value;
          const onMove = (ev:MouseEvent)=>{
            const dy = startY - ev.clientY;
            const nv = Math.min(max, Math.max(min, start + dy*(max-min)/200));
            onChange(parseFloat(nv.toFixed(4)));
          };
          const onUp = ()=>{ window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
          window.addEventListener('mousemove', onMove);
          window.addEventListener('mouseup', onUp);
        }}
        title={`${label ?? 'Param'}: ${value.toFixed(2)}`}>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-2 h-6 rounded-sm bg-white/90 origin-bottom" style={{ transform: `rotate(${angle}deg)` }} />
        </div>
      </div>
      {label && <div className="knob-label">{label}</div>}
      <div className="knob-value">{value.toFixed(2)}</div>
    </div>
  );
}
