
'use client';
import React from 'react';

type Props = {
  state: 'stopped'|'playing'|'paused';
  onPlay: ()=>void;
  onPause: ()=>void;
  onStop: ()=>void;
  onExport: ()=>void;
};

export default function Transport({ state, onPlay, onPause, onStop, onExport }: Props){
  return (
    <div className="glass p-3 flex items-center gap-3">
      <button className="btn" onClick={onPlay} disabled={state==='playing'}>▶️ Play</button>
      <button className="btn" onClick={onPause} disabled={state!=='playing'}>⏸️ Pause</button>
      <button className="btn" onClick={onStop}>⏹️ Stop</button>
      <div className="flex-1" />
      <button className="btn" onClick={onExport}>⬇️ Export Mix</button>
    </div>
  );
}
