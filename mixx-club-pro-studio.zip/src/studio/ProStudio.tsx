
'use client';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { MixxAudioEngine } from '@/src/audio/MixxAudioEngine';
import PluginKnob from './components/PluginKnob';
import Transport from './components/Transport';
import Timeline from './components/Timeline';

type TrackUi = { id: string; name: string; file?: File|null; duration?: number; };

export default function ProStudio(){
  const engineRef = useRef<MixxAudioEngine | null>(null);
  const [tracks, setTracks] = useState<TrackUi[]>([
    { id:'track1', name:'Lead Vocal' },
    { id:'track2', name:'Instrumental' }
  ]);
  const [state, setState] = useState<'stopped'|'playing'|'paused'>('stopped');
  const [playhead, setPlayhead] = useState(0);
  const [duration, setDuration] = useState(60);

  // FX params
  const [verbAmt, setVerbAmt] = useState(0.15);
  const [verbTime, setVerbTime] = useState(2.5);
  const [delTime, setDelTime] = useState(0.28);
  const [delFb, setDelFb] = useState(0.35);
  const [delWet, setDelWet] = useState(0.2);
  const [limThr, setLimThr] = useState(-4);
  const [clipAmt, setClipAmt] = useState(0.9);

  useEffect(()=>{
    const eng = new MixxAudioEngine();
    engineRef.current = eng;
    const id = requestAnimationFrame(function raf(){
      const t = eng.getPlayhead();
      setPlayhead(t);
      requestAnimationFrame(raf);
    });
    return ()=>{ cancelAnimationFrame(id); eng.stop(); };
  }, []);

  useEffect(()=>{ engineRef.current?.setVerb(verbAmt); }, [verbAmt]);
  useEffect(()=>{ engineRef.current?.setVerbTime(verbTime); }, [verbTime]);
  useEffect(()=>{ engineRef.current?.setDelayTime(delTime); }, [delTime]);
  useEffect(()=>{ engineRef.current?.setDelayFeedbackAmt(delFb); }, [delFb]);
  useEffect(()=>{ engineRef.current?.setDelayWet(delWet); }, [delWet]);
  useEffect(()=>{ engineRef.current?.setLimiterThreshold(limThr); }, [limThr]);
  useEffect(()=>{ engineRef.current?.setClip(clipAmt); }, [clipAmt]);

  const longest = useMemo(()=>Math.max(10, ...tracks.map(t=>t.duration ?? 0)), [tracks]);

  async function handleFile(i: number, file: File){
    const eng = engineRef.current!;
    const buffer = await eng.decodeFile(file);
    await eng.createTrack(tracks[i].id, buffer);
    const du = buffer.duration;
    setTracks(prev => prev.map((t,idx)=> idx===i ? ({...t, file, duration: du}) : t));
    setDuration(Math.max(longest, du));
  }

  function handleSeek(sec: number){
    const eng = engineRef.current!;
    if (state === 'playing'){
      eng.stop();
      eng.play(sec);
    } else {
      eng.pauseTime = sec;
      setPlayhead(sec);
    }
  }

  async function exportMix(){
    const eng = engineRef.current!;
    const blob = await eng.exportMix();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'mixxclub_export.wav';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center gap-3">
        <div className="text-2xl font-semibold">Mixx Club Pro Studio</div>
        <div className="px-2 py-1 rounded-md bg-prime-700/60 border border-white/10 text-xs">
          HybridDAW · artist x engineer x producer
        </div>
        <div className="flex-1" />
        <div className="text-sm text-white/70">Ravenis Prime · Inner Circle</div>
      </div>

      <Transport
        state={state}
        onPlay={()=>{ engineRef.current?.play(state==='paused' ? engineRef.current?.pauseTime ?? 0 : 0); setState('playing'); }}
        onPause={()=>{ engineRef.current?.pause(); setState('paused'); }}
        onStop={()=>{ engineRef.current?.stop(); setState('stopped'); setPlayhead(0); }}
        onExport={exportMix}
      />

      <Timeline duration={longest} playhead={playhead} onSeek={handleSeek}/>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="glass p-4 col-span-2">
          <div className="flex items-center justify-between mb-3">
            <div className="font-semibold">Tracks</div>
            <div className="text-xs text-white/60">Drop audio files per track</div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {tracks.map((t, i)=>(
              <div key={t.id} className="border border-white/10 rounded-md p-3 flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-white/10 flex items-center justify-center">{i+1}</div>
                <div className="flex-1">
                  <div className="font-medium">{t.name}</div>
                  <div className="text-xs text-white/60">{t.duration ? t.duration.toFixed(2)+'s' : 'No file'}</div>
                </div>
                <input type="file" accept="audio/*" onChange={(e)=>{
                  const file = e.target.files?.[0]; if (file) handleFile(i, file);
                }}/>
              </div>
            ))}
          </div>
        </div>

        <div className="glass p-4">
          <div className="font-semibold mb-2">Mix Bus</div>
          <div className="grid grid-cols-3 gap-4">
            <PluginKnob label="Verb Amt" value={verbAmt} min={0} max={1} step={0.01} onChange={setVerbAmt}/>
            <PluginKnob label="Verb Time" value={verbTime} min={0.3} max={6} step={0.01} onChange={setVerbTime}/>
            <PluginKnob label="Delay" value={delTime} min={0.05} max={1.2} step={0.005} onChange={setDelTime}/>
            <PluginKnob label="Feedback" value={delFb} min={0} max={0.95} step={0.01} onChange={setDelFb}/>
            <PluginKnob label="Delay Wet" value={delWet} min={0} max={1} step={0.01} onChange={setDelWet}/>
            <div />
            <PluginKnob label="Limiter" value={limThr} min={-24} max={0} step={0.5} onChange={setLimThr}/>
            <PluginKnob label="Clip Amt" value={clipAmt} min={0.2} max={1.2} step={0.01} onChange={setClipAmt}/>
          </div>
        </div>
      </div>

      <div className="glass p-4">
        <div className="font-semibold mb-2">Notes</div>
        <ul className="text-sm text-white/70 list-disc ml-5 space-y-1">
          <li>Live plugins: MixxVerb (convolution) · MixxDelay (feedback delay) · Limiter/Clipper on the Mix Bus.</li>
          <li>Drop your vocal and instrumental stems on the two starter tracks above.</li>
          <li>Export Mix performs offline render to WAV with master processing.</li>
          <li>All UI is portable — drop this project into a new Lovable project and run.</li>
        </ul>
      </div>
    </div>
  );
}
