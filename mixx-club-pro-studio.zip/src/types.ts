
export type TransportState = 'stopped' | 'playing' | 'paused';

export type PluginParam = {
  id: string;
  name: string;
  min: number;
  max: number;
  step?: number;
  value: number;
  unit?: string;
};

export type Track = {
  id: string;
  name: string;
  file?: File | null;
  buffer?: AudioBuffer | null;
  gain: number;
  muted: boolean;
  solo: boolean;
  pan: number; // -1..1
};

export type RenderOptions = {
  normalize?: boolean;
  targetLufs?: number; // future
};
