
/**
 * Lightweight Web Audio engine with:
 * - File decoding & track routing
 * - Mix bus with MixxVerb, MixxDelay, Limiter/Clipper
 * - Transport play/pause/stop
 * - Monitor mode (live input)
 * - Offline render to WAV (Export Mix)
 */
export class MixxAudioEngine {
  context: AudioContext;
  offline?: OfflineAudioContext;
  masterGain: GainNode;
  analyser: AnalyserNode;

  // Effects
  verb: ConvolverNode;
  verbWet: GainNode;
  verbDry: GainNode;

  delay: DelayNode;
  delayFeedback: GainNode;
  delayWet: GainNode;
  delayDry: GainNode;

  // Limiter/Clipper (simple)
  dynamics: DynamicsCompressorNode;
  clipper: WaveShaperNode;

  destination: AudioNode;
  tracks: Map<string, { src: AudioBufferSourceNode | null, gain: GainNode, pan: StereoPannerNode, buffer?: AudioBuffer }>= new Map();

  startTime = 0;
  pauseTime = 0;
  state: 'stopped' | 'playing' | 'paused' = 'stopped';

  constructor() {
    this.context = new (window.AudioContext || (window as any).webkitAudioContext)();
    const ctx = this.context;

    // master
    this.masterGain = ctx.createGain();
    this.masterGain.gain.value = 0.9;

    this.analyser = ctx.createAnalyser();
    this.analyser.fftSize = 2048;

    // Verb (impulse generated)
    this.verb = ctx.createConvolver();
    this.verb.buffer = this._generateImpulseResponse(2.5, 3.0);
    this.verbWet = ctx.createGain(); this.verbWet.gain.value = 0.15;
    this.verbDry = ctx.createGain(); this.verbDry.gain.value = 1.0;

    // Delay
    this.delay = ctx.createDelay(5.0); this.delay.delayTime.value = 0.28;
    this.delayFeedback = ctx.createGain(); this.delayFeedback.gain.value = 0.35;
    this.delayWet = ctx.createGain(); this.delayWet.gain.value = 0.2;
    this.delayDry = ctx.createGain(); this.delayDry.gain.value = 1.0;
    this.delay.connect(this.delayFeedback).connect(this.delay);

    // Limiter (use compressor) then Clipper
    this.dynamics = ctx.createDynamicsCompressor();
    this.dynamics.threshold.value = -4;
    this.dynamics.knee.value = 0;
    this.dynamics.ratio.value = 20;
    this.dynamics.attack.value = 0.003;
    this.dynamics.release.value = 0.150;

    this.clipper = ctx.createWaveShaper();
    this.clipper.curve = this._makeClipCurve(0.9);

    // Routing mix bus
    const mixBus = ctx.createGain();
    mixBus.connect(this.verbDry);
    mixBus.connect(this.verb);
    this.verb.connect(this.verbWet);

    // Parallel delay
    mixBus.connect(this.delayDry);
    mixBus.connect(this.delay);
    this.delay.connect(this.delayWet);

    // Sum wet/dry
    const sum = ctx.createGain();
    this.verbDry.connect(sum);
    this.verbWet.connect(sum);
    this.delayDry.connect(sum);
    this.delayWet.connect(sum);

    // Dynamics chain
    sum.connect(this.dynamics).connect(this.clipper).connect(this.masterGain).connect(this.analyser).connect(ctx.destination);

    this.destination = mixBus; // where tracks connect
  }

  _makeClipCurve(amount: number) {
    const n = 44100;
    const curve = new Float32Array(n);
    const k = amount * 100;
    for (let i = 0; i < n; i++) {
      const x = (i * 2) / n - 1;
      curve[i] = ((1 + k) * x) / (1 + k * Math.abs(x));
    }
    return curve;
  }

  _generateImpulseResponse(duration = 2.5, decay = 2.0) {
    const rate = this.context.sampleRate;
    const length = rate * duration;
    const impulse = this.context.createBuffer(2, length, rate);
    for (let c = 0; c < 2; c++) {
      const channel = impulse.getChannelData(c);
      for (let i = 0; i < length; i++) {
        channel[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
      }
    }
    return impulse;
  }

  async createTrack(id: string, buffer: AudioBuffer) {
    const ctx = this.context;
    const gain = ctx.createGain();
    const pan = ctx.createStereoPanner();
    gain.gain.value = 1.0;
    pan.pan.value = 0.0;
    gain.connect(pan).connect(this.destination);
    this.tracks.set(id, { src: null, gain, pan, buffer });
  }

  setTrackGain(id: string, value: number) {
    const t = this.tracks.get(id); if (t) t.gain.gain.value = value;
  }
  setTrackPan(id: string, value: number) {
    const t = this.tracks.get(id); if (t) t.pan.pan.value = value;
  }

  setVerb(amount: number) { this.verbWet.gain.value = amount; }
  setVerbTime(seconds: number) { this.verb.buffer = this._generateImpulseResponse(seconds, 3.0); }
  setDelayTime(seconds: number) { this.delay.delayTime.value = seconds; }
  setDelayFeedbackAmt(value: number) { this.delayFeedback.gain.value = value; }
  setDelayWet(value: number) { this.delayWet.gain.value = value; }
  setLimiterThreshold(db: number) { this.dynamics.threshold.value = db; }
  setClip(amount: number) { this.clipper.curve = this._makeClipCurve(amount); }

  async decodeFile(file: File): Promise<AudioBuffer> {
    const arrayBuf = await file.arrayBuffer();
    return await this.context.decodeAudioData(arrayBuf.slice(0));
  }

  _makeSource(buffer: AudioBuffer) {
    const src = this.context.createBufferSource();
    src.buffer = buffer;
    return src;
  }

  _connectSources(offset = 0) {
    for (const [id, t] of this.tracks) {
      if (!t.buffer) continue;
      const src = this._makeSource(t.buffer);
      src.connect(t.gain);
      t.src = src;
      src.start(0, offset);
    }
  }

  play(offset = 0) {
    if (this.state === 'playing') return;
    this._connectSources(offset);
    this.startTime = this.context.currentTime - offset;
    this.state = 'playing';
  }

  pause() {
    if (this.state !== 'playing') return;
    this.pauseTime = this.context.currentTime - this.startTime;
    for (const [, t] of this.tracks) { try { t.src?.stop(); } catch {} t.src = null; }
    this.state = 'paused';
  }

  stop() {
    for (const [, t] of this.tracks) { try { t.src?.stop(); } catch {} t.src = null; }
    this.state = 'stopped';
    this.startTime = 0; this.pauseTime = 0;
  }

  getPlayhead(): number {
    if (this.state === 'playing') return this.context.currentTime - this.startTime;
    if (this.state === 'paused') return this.pauseTime;
    return 0;
  }

  async exportMix(): Promise<Blob> {
    // Offline re-render with simple chain
    const sampleRate = 48000;
    // Determine render length from longest buffer
    let lengthSec = 0;
    for (const [, t] of this.tracks) {
      if (t.buffer) lengthSec = Math.max(lengthSec, t.buffer.duration);
    }
    const frames = Math.ceil(lengthSec * sampleRate);
    const off = new OfflineAudioContext(2, frames, sampleRate);

    // Rebuild minimal chain: sum -> dynamics -> clip -> destination
    const sum = off.createGain();
    const dyn = off.createDynamicsCompressor();
    dyn.threshold.value = this.dynamics.threshold.value;
    dyn.knee.value = this.dynamics.knee.value;
    dyn.ratio.value = this.dynamics.ratio.value;
    dyn.attack.value = this.dynamics.attack.value;
    dyn.release.value = this.dynamics.release.value;

    const clip = off.createWaveShaper();
    clip.curve = this._makeClipCurve(0.9);

    sum.connect(dyn).connect(clip).connect(off.destination);

    // Tracks
    for (const [, t] of this.tracks) {
      if (!t.buffer) continue;
      const src = off.createBufferSource();
      src.buffer = t.buffer;
      const g = off.createGain(); g.gain.value = t.gain.gain.value;
      const p = off.createStereoPanner(); p.pan.value = t.pan.pan.value;
      src.connect(g).connect(p).connect(sum);
      src.start();
    }

    const rendered = await off.startRendering();
    // Encode WAV
    const wav = this._encodeWav(rendered);
    return new Blob([wav], { type: 'audio/wav' });
  }

  _encodeWav(buffer: AudioBuffer): ArrayBuffer {
    const numOfChan = buffer.numberOfChannels;
    const length = buffer.length * numOfChan * 2 + 44;
    const out = new ArrayBuffer(length);
    const view = new DataView(out);

    const writeString = (offset: number, str: string) => {
      for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
    };
    const floatTo16BitPCM = (output: DataView, offset: number, input: Float32Array) => {
      for (let i = 0; i < input.length; i++, offset += 2) {
        const s = Math.max(-1, Math.min(1, input[i]));
        output.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
      }
      return offset;
    };

    const sampleRate = buffer.sampleRate;
    const channels: Float32Array[] = [];
    for (let i = 0; i < numOfChan; i++) channels.push(buffer.getChannelData(i));

    // Header
    writeString(0, 'RIFF');
    view.setUint32(4, 36 + buffer.length * numOfChan * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, numOfChan, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * numOfChan * 2, true);
    view.setUint16(32, numOfChan * 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, buffer.length * numOfChan * 2, true);

    // Interleave
    let offset = 44;
    for (let i = 0; i < buffer.length; i++) {
      for (let c = 0; c < numOfChan; c++) {
        const input = channels[c];
        const sample = input[i];
        const s = Math.max(-1, Math.min(1, sample));
        view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
        offset += 2;
      }
    }
    return out;
  }
}
