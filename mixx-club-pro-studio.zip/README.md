
# Mixx Club Pro Studio (Lovable-ready)

A minimal, working HybridDAW for Mixx Club Online — built with **Next.js (App Router) + TypeScript + Tailwind** and a compact **Web Audio** engine.

## Quickstart

```bash
npm i
npm run dev
```

Open http://localhost:3000

## Features

- Transport (Play/Pause/Stop) + Timeline seek
- Two starter tracks: Lead Vocal + Instrumental (drag/drop via file inputs)
- Mix Bus with **MixxVerb**, **MixxDelay**, **Limiter/Clipper**
- **Export Mix** → offline render to WAV
- Clean, glass UI in Mixx Club palette
- No backend required

## Drop-in for Lovable

1. Create a **new Lovable** project.
2. Upload the entire zipped folder or copy files into the generated repo.
3. Ensure Node 18+ and `npm i` then `npm run dev`.

## Where to extend

- Add more tracks and per-track plugin chains in `src/audio/MixxAudioEngine.ts` and `src/studio/ProStudio.tsx`.
- Replace impulse response generation with IR files for refined reverb.
- Wire up **MixxPort, telemetry, Inner Circle auth**, etc.
